EF Core Migrations
------------------

This repository is configured to use EF Core 8/SqlServer for persistence. To create and apply migrations locally (or in CI), run:

# From solution root (TestService.sln)
# 1) Install dotnet-ef tool if needed (once)
dotnet tool install --global dotnet-ef --version 8.0.11

# 2) Add migration (example)
dotnet ef migrations add InitialCreate --project src/Infrastructure/TestService.Infrastructure.csproj --startup-project src/API/TestService.API.csproj -o Persistence/Migrations

# 3) Apply migration to SQL Server (ensure connection string is set in appsettings.Production.json)
dotnet ef database update --project src/Infrastructure/TestService.Infrastructure.csproj --startup-project src/API/TestService.API.csproj

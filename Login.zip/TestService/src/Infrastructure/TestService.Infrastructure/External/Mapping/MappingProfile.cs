﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestService.Application.Weather.Dtos;
using TestService.Infrastructure.External.Models;

namespace TestService.Infrastructure.External.Mapping
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<OpenMeteoResponse, WeatherResult>()
                .ForMember(d => d.Latitude, o => o.MapFrom(s => s.Latitude))
                .ForMember(d => d.Longitude, o => o.MapFrom(s => s.Longitude))
                .ForMember(d => d.Elevation, o => o.MapFrom(s => s.Elevation))
                .ForMember(d => d.Timezone, o => o.MapFrom(s => s.Timezone))
                .ForMember(d => d.Time, o => o.MapFrom(s => s.CurrentWeather.Time))
                .ForMember(d => d.Temperature, o => o.MapFrom(s => s.CurrentWeather.Temperature))
                .ForMember(d => d.WindSpeed, o => o.MapFrom(s => s.CurrentWeather.Windspeed))
                .ForMember(d => d.WindDirection, o => o.MapFrom(s => s.CurrentWeather.Winddirection))
                .ForMember(d => d.WeatherCode, o => o.MapFrom(s => s.CurrentWeather.Weathercode))
                .ForMember(d => d.IsDay, o => o.MapFrom(s => s.CurrentWeather.IsDay));
        }
    }
}

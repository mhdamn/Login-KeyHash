using System.Threading.Tasks;
using TestService.Application.Common.Interfaces;

namespace TestService.Infrastructure.External
{
    public class EmailService : IEmailService
    {
        public Task SendEmailAsync(string to, string subject, string body)
        {
            // placeholder for real email sending
            return Task.CompletedTask;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace TestService.Infrastructure.External.Models
{
    public sealed record OpenMeteoResponse
    {
        public required double Latitude { get; init; }
        public required double Longitude { get; init; }
        
        [JsonPropertyName("generationtime_ms")]
        public required double GenerationtimeMs { get; init; }
        
        [JsonPropertyName("utc_offset_seconds")]
        public required int UtcOffsetSeconds { get; init; }
        public required string Timezone { get; init; }
        
        [JsonPropertyName("timezone_abbreviation")]
        public required string TimezoneAbbreviation { get; init; }
        public required double Elevation { get; init; }

        [JsonPropertyName("current_weather_units")]
        public required CurrentWeatherUnits CurrentWeatherUnits { get; init; }

        [JsonPropertyName("current_weather")]
        public required CurrentWeather CurrentWeather { get; init; }
    }

    public sealed record CurrentWeatherUnits
    {
        public required string Time { get; init; }
        public required string Interval { get; init; }
        public required string Temperature { get; init; }
        public required string Windspeed { get; init; }
        public required string Winddirection { get; init; }
        public string? IsDay { get; init; }
        public required string Weathercode { get; init; }
    }

    public sealed record CurrentWeather
    {
        public required string Time { get; init; }
        public required int Interval { get; init; }
        public required double Temperature { get; init; }
        public required double Windspeed { get; init; }
        public required int Winddirection { get; init; }

        [JsonPropertyName("is_day")]
        public required int IsDay { get; init; }
        public required int Weathercode { get; init; }
    }
}

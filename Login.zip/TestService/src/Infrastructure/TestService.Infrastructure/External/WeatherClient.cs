﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TestService.Application.Common.Interfaces;
using TestService.Application.Weather.Dtos;
using TestService.Infrastructure.External.Models;
using static System.Net.WebRequestMethods;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace TestService.Infrastructure.External
{
    public class WeatherClient : IWeatherClient
    {
        private readonly HttpClient _http;
        private readonly IMapper _mapper;

        public WeatherClient(HttpClient http,IMapper mapper)
        {
            _http = http;
            _mapper = mapper;
        }

        public async Task<WeatherResult> GetWeatherAsync(double latitude, double longitude, CancellationToken cancellationToken)
        {
            // Example: GET https://api.open-meteo.com/v1/forecast?latitude=35&longitude=139&current_weather=true
            var url = $"forecast?latitude={latitude}&longitude={longitude}&current_weather=true";
            var response = await _http.GetAsync(url, cancellationToken);

            response.EnsureSuccessStatusCode();

            var data = await response.Content.ReadFromJsonAsync<OpenMeteoResponse>(cancellationToken: cancellationToken);
            if (data?.CurrentWeather == null)
                throw new InvalidOperationException("Weather data unavailable.");

            var result = _mapper.Map<WeatherResult>(data);
            return result;
        }

    }
}

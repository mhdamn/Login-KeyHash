using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Reflection;
using System.Text.Json;
using TestService.Application.Common.Interfaces;
using TestService.Infrastructure.External;
using TestService.Infrastructure.External.Mapping;
using TestService.Infrastructure.Persistence;
using TestService.Infrastructure.Persistence.Repositories;
using TestService.Infrastructure.Services;

namespace TestService.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            var useInMemory = configuration.GetValue<bool>("UseInMemoryDatabase");
            if (useInMemory)
            {
                services.AddDbContext<AppDbContext>(options => options.UseInMemoryDatabase("TestServiceDb"));
            }
            else
            {
                services.AddDbContext<AppDbContext>(options => options.UseSqlServer(configuration.GetConnectionString("DefaultConnection")));
            }

            services.AddAutoMapper(cfg => { }, Assembly.GetExecutingAssembly());

            services.AddScoped<IApplicationDbContext>(provider => provider.GetRequiredService<AppDbContext>());
            services.AddScoped<IAuthService, AuthService>();
            services.AddScoped<IOrderRepository, OrderRepository>();
            services.AddScoped<IEmailService, EmailService>();
            services.AddHttpClient<IWeatherClient, WeatherClient>(client =>
            {
                client.BaseAddress = new Uri(configuration["ExternalApis:WeatherApiBaseUrl"]!);
                client.DefaultRequestHeaders.Add("Accept", "application/json");
            });

            //services.ConfigureHttpJsonOptions(options =>
            //{
            //    options.SerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower;
            //});

            return services;
        }
    }
}

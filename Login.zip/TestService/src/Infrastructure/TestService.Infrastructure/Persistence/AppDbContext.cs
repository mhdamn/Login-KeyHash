using Microsoft.EntityFrameworkCore;
using TestService.Domain.Entities;
using TestService.Application.Common.Interfaces;
using System.Threading.Tasks;
using System.Threading;
using System;

namespace TestService.Infrastructure.Persistence
{
    public class AppDbContext : DbContext, IApplicationDbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Order> Orders => Set<Order>();
        public DbSet<OrderItem> OrderItems => Set<OrderItem>();
        public DbSet<RefreshToken> RefreshTokens { get; set; } = null!;

        Task<int> IApplicationDbContext.SaveChangesAsync(CancellationToken cancellationToken)
            => base.SaveChangesAsync(cancellationToken);

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Order>(b =>
            {
                b.HasKey(o => o.Id);
                b.OwnsMany(o => o.Items, ib =>
                {
                    ib.WithOwner().HasForeignKey("OrderId");
                    ib.Property<Guid>("Id");
                    ib.HasKey("Id");
                });
            });
        }
    }
}

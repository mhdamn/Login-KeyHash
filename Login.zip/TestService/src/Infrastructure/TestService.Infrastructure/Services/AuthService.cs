﻿using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TestService.Application.Common.Interfaces;
using TestService.Domain.Entities;
using TestService.Infrastructure.Persistence;

namespace TestService.Infrastructure.Services
{
    public class AuthService : IAuthService
    {
        private readonly IConfiguration _config;
        private readonly IApplicationDbContext _db;

        public AuthService(IConfiguration config, IApplicationDbContext db)
        {
            _config = config;
            _db = db;
        }

        // Access token (JWT)
        public string GenerateAccessToken(string userId, string role)
        {
            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, userId),
                new Claim(ClaimTypes.Role, role)
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]!));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var jwt = new JwtSecurityToken(
                issuer: _config["Jwt:Issuer"],
                audience: _config["Jwt:Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddMinutes(int.Parse(_config["Jwt:AccessTokenMinutes"] ?? "15")),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(jwt);
        }

        // Refresh token: generate raw token + hashed token for DB
        public (string refreshToken, RefreshToken refreshTokenEntity) GenerateRefreshToken(string userId)
        {
            // generate cryptographically strong random token
            var randomBytes = new byte[64];
            using var rng = RandomNumberGenerator.Create();
            rng.GetBytes(randomBytes);
            var rawToken = Convert.ToBase64String(randomBytes);

            // hash the token for storage (use a secure KDF)
            var salt = new byte[16];
            using var rngSalt = RandomNumberGenerator.Create();
            rngSalt.GetBytes(salt);
            var saltString = Convert.ToBase64String(salt);

            var hashed = HashToken(rawToken, saltString);

            var expires = DateTime.UtcNow.AddDays(int.Parse(_config["Jwt:RefreshTokenDays"] ?? "7"));
            var entity = new RefreshToken($"{saltString}:{hashed}", expires, userId); // store "salt:hash"

            return (rawToken, entity);
        }

        // Save refresh token entity
        public async Task SaveRefreshTokenAsync(RefreshToken refreshToken)
        {
            _db.RefreshTokens.Add(refreshToken);
            await _db.SaveChangesAsync(CancellationToken.None);
        }

        // Get refresh token entity by matching hash
        public async Task<RefreshToken?> GetRefreshTokenByHashAsync(string tokenHash)
        {
            return await _db.RefreshTokens.FirstOrDefaultAsync(rt => rt.TokenHash == tokenHash);
        }

        public async Task<RefreshToken?> GetRefreshTokenByRawTokenAsync(string rawToken)
        {
            // load only tokens that are not revoked and not expired
            var candidates = await _db.RefreshTokens
                .Where(rt => !rt.IsRevoked && DateTime.UtcNow < rt.Expires)
                .ToListAsync();

            foreach (var candidate in candidates)
            {
                // VerifyToken(rawToken, storedSaltAndHash) already exists in this class
                if (VerifyToken(rawToken, candidate.TokenHash))
                    return candidate;
            }

            return null;
        }

        // Revoke
        public async Task RevokeRefreshTokenAsync(RefreshToken refreshToken)
        {
            refreshToken.Revoke();
            await _db.SaveChangesAsync(CancellationToken.None);
        }

        // Helpers
        private string HashToken(string token, string salt)
        {
            var saltBytes = Convert.FromBase64String(salt);
            var hashed = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                password: token,
                salt: saltBytes,
                prf: KeyDerivationPrf.HMACSHA256,
                iterationCount: 100_000,
                numBytesRequested: 32));
            return hashed;
        }

        // Utility to verify incoming raw token against stored "salt:hash"
        private bool VerifyToken(string rawToken, string storedSaltAndHash)
        {
            var parts = storedSaltAndHash.Split(':', 2);
            if (parts.Length != 2) return false;
            var salt = parts[0];
            var storedHash = parts[1];
            var hashOfInput = HashToken(rawToken, salt);
            return CryptographicEquals(hashOfInput, storedHash);
        }

        private bool CryptographicEquals(string a, string b)
        {
            var aBytes = Convert.FromBase64String(a);
            var bBytes = Convert.FromBase64String(b);
            if (aBytes.Length != bBytes.Length) return false;
            var diff = 0;
            for (var i = 0; i < aBytes.Length; i++) diff |= aBytes[i] ^ bBytes[i];
            return diff == 0;
        }
    }
}

﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TestService.Application.Auth.Commands.Login;
using TestService.Application.Auth.Commands.RefreshToken;
using TestService.Application.Auth.Commands.RevokeToken;
using TestService.Application.Auth.Dtos;

namespace TestService.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IMediator _mediator;

        public AuthController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// Login endpoint — issues access and refresh tokens.
        /// </summary>
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest req)
        {
            if (string.IsNullOrWhiteSpace(req.Username) || string.IsNullOrWhiteSpace(req.Password))
                return BadRequest("Missing credentials");

            var result = await _mediator.Send(new LoginCommand(req.Username, req.Password));
            return Ok(result);
        }

        /// <summary>
        /// Refresh endpoint — exchanges a valid refresh token for new tokens.
        /// </summary>
        [HttpPost("refresh")]
        public async Task<ActionResult<AuthResult>> Refresh([FromBody] RefreshRequest req)
        {
            if (string.IsNullOrWhiteSpace(req.RefreshToken))
                return BadRequest("Missing refresh token");

            var result = await _mediator.Send(new RefreshTokenCommand(req.RefreshToken));
            return Ok(result);
        }

        /// <summary>
        /// Revoke endpoint — invalidates a refresh token.
        /// </summary>
        [HttpPost("revoke")]
        public async Task<IActionResult> Revoke([FromBody] RefreshRequest req)
        {
            if (string.IsNullOrWhiteSpace(req.RefreshToken))
                return BadRequest("Missing refresh token");

            await _mediator.Send(new RevokeTokenCommand(req.RefreshToken));
            return NoContent();
        }
    }
}

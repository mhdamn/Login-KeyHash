﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using TestService.Application.Weather.Queries;

namespace TestService.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class WeatherController : ControllerBase
    {
        private readonly IMediator _mediator;

        public WeatherController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        public async Task<IActionResult> Get([FromQuery] double lat = 52.52, [FromQuery] double lon = 13.419998)
        {
            var result = await _mediator.Send(new GetWeatherQuery(lat, lon));
            return Ok(result);
        }
    }
}

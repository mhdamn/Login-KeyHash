using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using TestService.Application.Common.Result;
using TestService.Application.Orders.Commands.CreateOrder;
using TestService.Application.Orders.Queries.GetOrderById;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace TestService.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrdersController : ControllerBase
    {
        private readonly IMediator _mediator;

        public OrdersController(IMediator mediator) => _mediator = mediator;

        [HttpGet("{id:guid}")]
        [Authorize]
        [SwaggerOperation(Summary = "Get order by id (requires authentication)")]
        public async Task<IActionResult> GetOrder(Guid id)
        {
            var result = await _mediator.Send(new GetOrderByIdQuery(id));
            return result.Type switch
            {
                ResultType.Success => Ok(result.Value),
                ResultType.NotFound => NotFound(new { message = result.Error }),
                _ => StatusCode(500, new { message = result.Error })
            };
        }

        [HttpPost]
        [SwaggerOperation(Summary = "Public endpoint (no authentication required)")]
        public async Task<IActionResult> CreateOrder([FromBody] CreateOrderCommand command)
        {
            var orderId = await _mediator.Send(command);
            return CreatedAtAction(nameof(GetOrder), new { id = orderId }, new { id = orderId });
        }
    }
}

﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestService.Application.Common.Interfaces;

namespace TestService.Application.Auth.Commands.RevokeToken
{
    public class RevokeTokenCommandHandler : IRequestHandler<RevokeTokenCommand,Unit>
    {
        private readonly IAuthService _auth;

        public RevokeTokenCommandHandler(IAuthService auth)
        {
            _auth = auth;
        }

        public async Task<Unit> Handle(RevokeTokenCommand request, CancellationToken cancellationToken)
        {
            var tokenEntity = await _auth.GetRefreshTokenByRawTokenAsync(request.RefreshToken);
            if (tokenEntity == null)
                return Unit.Value; // silently ignore or throw NotFoundException if you prefer

            await _auth.RevokeRefreshTokenAsync(tokenEntity);
            return Unit.Value;
        }
    }
}

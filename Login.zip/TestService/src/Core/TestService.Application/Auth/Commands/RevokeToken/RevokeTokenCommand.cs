﻿using MediatR;

namespace TestService.Application.Auth.Commands.RevokeToken
{
    public record RevokeTokenCommand(string RefreshToken) : IRequest<Unit>;
}

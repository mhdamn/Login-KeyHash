﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestService.Application.Auth.Dtos;

namespace TestService.Application.Auth.Commands.Login
{
    public record LoginCommand(string Username, string Password) : IRequest<AuthResult>;
}

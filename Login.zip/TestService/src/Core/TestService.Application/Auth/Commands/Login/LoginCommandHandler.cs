﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestService.Application.Auth.Dtos;
using TestService.Application.Common.Interfaces;

namespace TestService.Application.Auth.Commands.Login
{
    public class LoginCommandHandler : IRequestHandler<LoginCommand, AuthResult>
    {
        private readonly IAuthService _auth;

        public LoginCommandHandler(IAuthService auth)
        {
            _auth = auth;
        }

        public async Task<AuthResult> Handle(LoginCommand request, CancellationToken cancellationToken)
        {
            // In real app, validate credentials via IUserRepository or IIdentityService
            if (request.Username != "admin" || request.Password != "1234")
                throw new UnauthorizedAccessException("Invalid credentials");

            var userId = "1";
            var role = "Admin";

            var accessToken = _auth.GenerateAccessToken(userId, role);
            var (refreshToken, refreshEntity) = _auth.GenerateRefreshToken(userId);
            await _auth.SaveRefreshTokenAsync(refreshEntity);

            return new AuthResult
            {
                AccessToken = accessToken,
                RefreshToken = refreshToken
            };
        }
    }
}

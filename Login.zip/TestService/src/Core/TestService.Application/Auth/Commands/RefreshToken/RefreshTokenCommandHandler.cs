﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestService.Application.Auth.Dtos;
using TestService.Application.Common.Interfaces;

namespace TestService.Application.Auth.Commands.RefreshToken
{
    public class RefreshTokenCommandHandler : IRequestHandler<RefreshTokenCommand, AuthResult>
    {
        private readonly IAuthService _auth;

        public RefreshTokenCommandHandler(IAuthService auth)
        {
            _auth = auth;
        }

        public async Task<AuthResult> Handle(RefreshTokenCommand request, CancellationToken cancellationToken)
        {
            if (string.IsNullOrWhiteSpace(request.RefreshToken))
                throw new UnauthorizedAccessException("Missing refresh token");

            // Find the refresh token entity by verifying the raw token against stored salt:hash
            var existing = await _auth.GetRefreshTokenByRawTokenAsync(request.RefreshToken);

            if (existing is null || !existing.IsActive)
                throw new UnauthorizedAccessException("Invalid or expired refresh token");

            // rotate: revoke old
            await _auth.RevokeRefreshTokenAsync(existing);

            // create new tokens
            var newAccess = _auth.GenerateAccessToken(existing.UserId, "User");
            var (newRefreshRaw, newRefreshEntity) = _auth.GenerateRefreshToken(existing.UserId);
            await _auth.SaveRefreshTokenAsync(newRefreshEntity);

            return new AuthResult
            {
                AccessToken = newAccess,
                RefreshToken = newRefreshRaw
            };
        }
    }
}

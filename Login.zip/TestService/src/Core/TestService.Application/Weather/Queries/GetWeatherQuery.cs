﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestService.Application.Weather.Dtos;

namespace TestService.Application.Weather.Queries
{
    public record GetWeatherQuery(double Latitude, double Longitude) : IRequest<WeatherResult>;
}

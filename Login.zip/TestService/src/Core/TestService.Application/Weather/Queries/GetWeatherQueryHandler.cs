﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestService.Application.Common.Interfaces;
using TestService.Application.Weather.Dtos;

namespace TestService.Application.Weather.Queries
{
    public class GetWeatherQueryHandler : IRequestHandler<GetWeatherQuery, WeatherResult>
    {
        private readonly IWeatherClient _weatherClient;

        public GetWeatherQueryHandler(IWeatherClient weatherClient)
        {
            _weatherClient = weatherClient;
        }

        public async Task<WeatherResult> Handle(GetWeatherQuery request, CancellationToken cancellationToken)
        {
            return await _weatherClient.GetWeatherAsync(request.Latitude, request.Longitude, cancellationToken);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestService.Application.Weather.Dtos
{
    public sealed record WeatherResult
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public double Elevation { get; set; }
        public string Timezone { get; set; } = string.Empty;
        public DateTime Time { get; set; }
        public double Temperature { get; set; }
        public double WindSpeed { get; set; }
        public int WindDirection { get; set; }
        public int WeatherCode { get; set; }
        public bool IsDay { get; set; }

    }
}

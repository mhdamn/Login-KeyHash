using TestService.Domain.Entities;

namespace TestService.Application.Common.Interfaces
{
    public interface IOrderRepository
    {
        Task<Order?> GetByIdAsync(Guid id);
        Task AddAsync(Order order);
    }
}

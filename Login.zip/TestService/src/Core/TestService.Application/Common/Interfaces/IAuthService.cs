﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestService.Domain.Entities;

namespace TestService.Application.Common.Interfaces
{
    public interface IAuthService
    {
        string GenerateAccessToken(string userId, string role);
        (string refreshToken, RefreshToken refreshTokenEntity) GenerateRefreshToken(string userId);
        Task SaveRefreshTokenAsync(RefreshToken refreshToken);
        Task<RefreshToken?> GetRefreshTokenByHashAsync(string tokenHash);
        Task<RefreshToken?> GetRefreshTokenByRawTokenAsync(string rawToken);
        Task RevokeRefreshTokenAsync(RefreshToken refreshToken);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestService.Application.Weather.Dtos;

namespace TestService.Application.Common.Interfaces
{
    public interface IWeatherClient
    {
        Task<WeatherResult> GetWeatherAsync(double latitude, double longitude, CancellationToken cancellationToken);
    }
}

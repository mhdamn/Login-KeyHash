using System;

namespace TestService.Application.Common.Result
{
    public class Result
    {
        public bool IsSuccess => Type == ResultType.Success;
        public bool IsFailure => !IsSuccess;
        public string? Error { get; }
        public ResultType Type { get; }

        protected Result(ResultType type, string? error)
        {
            if (type == ResultType.Success && error != null)
                throw new InvalidOperationException("Success result cannot have an error message.");

            if (type != ResultType.Success && string.IsNullOrWhiteSpace(error))
                throw new InvalidOperationException("Non-success result must have an error message.");

            Type = type;
            Error = error;
        }

        public static Result Success() => new(ResultType.Success, null);
        public static Result NotFound(string error) => new(ResultType.NotFound, error);
        public static Result ValidationError(string error) => new(ResultType.ValidationError, error);
        public static Result Conflict(string error) => new(ResultType.Conflict, error);
        public static Result Failure(string error) => new(ResultType.Failure, error);
        public static implicit operator Result(string error) => Failure(error);
    }

    public class Result<T> : Result
    {
        public T? Value { get; }

        private Result(T? value, ResultType type, string? error) : base(type, error)
        {
            Value = value;
        }

        public static Result<T> Success(T value) => new(value, ResultType.Success, null);
        public static Result<T> NotFound(string error) => new(default, ResultType.NotFound, error);
        public static Result<T> ValidationError(string error) => new(default, ResultType.ValidationError, error);
        public static Result<T> Conflict(string error) => new(default, ResultType.Conflict, error);
        public static Result<T> Failure(string error) => new(default, ResultType.Failure, error);

        public Result<K> Map<K>(Func<T, K> mapper)
        {
            if (IsFailure)
                return Result<K>.Failure(Error!);
            return Result<K>.Success(mapper(Value!));
        }

        public static implicit operator Result<T>(string error) => Failure(error);
    }
}

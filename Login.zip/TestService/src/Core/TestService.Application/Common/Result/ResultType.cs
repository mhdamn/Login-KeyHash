namespace TestService.Application.Common.Result
{
    public enum ResultType { Success, NotFound, ValidationError, Conflict, Failure }
}

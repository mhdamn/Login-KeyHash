using AutoMapper;
using TestService.Application.Orders.Dtos;
using TestService.Domain.Entities;

namespace TestService.Application.Mapping
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<OrderItem, OrderItemDto>();
            CreateMap<Order, OrderDto>()
                .ForMember(dst => dst.Items, opt => opt.MapFrom(src => src.Items))
                .ForMember(dst => dst.Total, opt => opt.MapFrom(src => src.Total));
        }
    }
}

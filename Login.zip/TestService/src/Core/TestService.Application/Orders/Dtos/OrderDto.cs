using System;
using System.Collections.Generic;

namespace TestService.Application.Orders.Dtos
{
    public record OrderDto(Guid Id, string Customer, DateTime CreatedAt, decimal Total, IReadOnlyCollection<OrderItemDto> Items);
    public record OrderItemDto(Guid Id, string Product, int Quantity, decimal Price, decimal Total);
}

using AutoMapper;
using MediatR;
using TestService.Application.Common.Interfaces;
using TestService.Application.Common.Result;
using TestService.Application.Orders.Dtos;
using Microsoft.EntityFrameworkCore;

namespace TestService.Application.Orders.Queries.GetOrderById
{
    public class GetOrderByIdHandler : IRequestHandler<GetOrderByIdQuery, Result<OrderDto>>
    {
        private readonly IOrderRepository _repository;
        private readonly IMapper _mapper;

        public GetOrderByIdHandler(IOrderRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        public async Task<Result<OrderDto>> Handle(GetOrderByIdQuery request, CancellationToken cancellationToken)
        {
            var order = await _repository.GetByIdAsync(request.Id);
            if (order == null) return Result<OrderDto>.NotFound("Order not found");
            var dto = _mapper.Map<OrderDto>(order);
            return Result<OrderDto>.Success(dto);
        }
    }
}

using MediatR;
using TestService.Application.Common.Result;
using TestService.Application.Orders.Dtos;
using System;

namespace TestService.Application.Orders.Queries.GetOrderById
{
    public record GetOrderByIdQuery(Guid Id) : IRequest<Result<OrderDto>>;
}

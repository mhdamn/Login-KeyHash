﻿using MediatR;
using TestService.Application.Common.Interfaces;
using TestService.Domain.Entities;

namespace TestService.Application.Orders.Commands.CreateOrder
{
    public class CreateOrderCommandHandler : IRequestHandler<CreateOrderCommand, Guid>
    {
        private readonly IApplicationDbContext _context;

        public CreateOrderCommandHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<Guid> Handle(CreateOrderCommand request, CancellationToken cancellationToken)
        {
            var order = new Order(request.Customer);

            foreach (var item in request.Items)
            {
                order.AddItem(new OrderItem(item.Product, item.Quantity, item.Price));
            }

            _context.Orders.Add(order);
            await _context.SaveChangesAsync(cancellationToken);

            return order.Id;
        }
    }
}

﻿using MediatR;

namespace TestService.Application.Orders.Commands.CreateOrder
{
    public record CreateOrderItemDto(string Product, int Quantity, decimal Price);
    public record CreateOrderCommand(string Customer, List<CreateOrderItemDto> Items) : IRequest<Guid>;
}

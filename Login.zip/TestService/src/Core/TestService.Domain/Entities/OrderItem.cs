using System;

namespace TestService.Domain.Entities
{
    public class OrderItem
    {
        public Guid Id { get; private set; }
        public string Product { get; private set; } = string.Empty;
        public int Quantity { get; private set; }
        public decimal Price { get; private set; }
        public decimal Total => Quantity * Price;

        protected OrderItem() { }

        public OrderItem(string product, int quantity, decimal price)
        {
            Id = Guid.NewGuid();
            Product = product;
            Quantity = quantity;
            Price = price;
        }
    }
}

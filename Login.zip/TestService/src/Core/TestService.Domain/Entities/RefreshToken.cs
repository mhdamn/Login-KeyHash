﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestService.Domain.Entities
{
    public class RefreshToken
    {
        public Guid Id { get; private set; } = Guid.NewGuid();
        public string TokenHash { get; private set; } = string.Empty; // store hashed token
        public DateTime Expires { get; private set; }
        public bool IsRevoked { get; private set; }
        public string UserId { get; private set; } = string.Empty;
        public DateTime CreatedAt { get; private set; } = DateTime.UtcNow;

        protected RefreshToken() { }

        public RefreshToken(string tokenHash, DateTime expires, string userId)
        {
            TokenHash = tokenHash;
            Expires = expires;
            UserId = userId;
        }

        public bool IsActive => !IsRevoked && DateTime.UtcNow < Expires;
        public void Revoke() => IsRevoked = true;
    }
}

using System;
using System.Collections.Generic;
using System.Linq;

namespace TestService.Domain.Entities
{
    public class Order
    {
        public Guid Id { get; private set; }
        public string Customer { get; private set; } = string.Empty;
        private readonly List<OrderItem> _items = new();
        public IReadOnlyCollection<OrderItem> Items => _items.AsReadOnly();
        public DateTime CreatedAt { get; private set; } = DateTime.UtcNow;

        protected Order() { }

        public Order(string customer)
        {
            Id = Guid.NewGuid();
            Customer = customer;
        }

        public void AddItem(OrderItem item) => _items.Add(item);

        public decimal Total => _items.Sum(i => i.Total);
    }
}

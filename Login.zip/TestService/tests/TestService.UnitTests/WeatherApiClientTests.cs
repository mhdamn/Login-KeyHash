﻿using AutoMapper;
using Castle.Core.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Moq.Protected;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace TestService.UnitTests
{
    public class WeatherApiClientTests
    {
        private readonly IMapper _mapper;
        private readonly IConfiguration _config;
        private readonly ILogger<WeatherApiClient> _logger;

        public WeatherApiClientTests()
        {
            var configDict = new Dictionary<string, string>
            {
                {"External:WeatherApiBaseUrl", "https://api.open-meteo.com/v1/"}
            };
            _config = new ConfigurationBuilder().AddInMemoryCollection(configDict).Build();

            var mapperConfig = new MapperConfiguration(cfg => cfg.AddProfile<ExternalMappingProfile>());
            _mapper = mapperConfig.CreateMapper();

            var loggerFactory = LoggerFactory.Create(builder => builder.AddConsole());
            _logger = loggerFactory.CreateLogger<WeatherApiClient>();
        }

        [Fact]
        public async Task Should_Call_OpenMeteo_And_MapResponse()
        {
            // Arrange
            var fakeJson = """
            {
              "latitude": 52.52,
              "longitude": 13.419998,
              "generationtime_ms": 0.05435943603515625,
              "utc_offset_seconds": 0,
              "timezone": "GMT",
              "timezone_abbreviation": "GMT",
              "elevation": 40,
              "current_weather": {
                "time": "2025-10-29T08:30",
                "interval": 900,
                "temperature": 9.1,
                "windspeed": 10.5,
                "winddirection": 218,
                "is_day": 1,
                "weathercode": 3
              }
            }
            """;

            var handlerMock = new Mock<HttpMessageHandler>();
            handlerMock.Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent(fakeJson),
                });

            var httpClient = new HttpClient(handlerMock.Object)
            {
                BaseAddress = new Uri("https://api.open-meteo.com/v1/")
            };

            var client = new WeatherApiClient(httpClient, _config, _logger, _mapper);

            // Act
            var result = await client.GetCurrentWeatherAsync(52.52, 13.419998);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(52.52, result.Latitude);
            Assert.Equal(9.1, result.Temperature);
            Assert.Equal(10.5, result.WindSpeed);
            Assert.Equal(218, result.WindDirection);
        }
    }
}

using AutoMapper;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;
using System;
using System.Threading;
using System.Threading.Tasks;
using TestService.Application.Common.Interfaces;
using TestService.Application.Orders.Queries.GetOrderById;
using TestService.Domain.Entities;
using Xunit;

namespace TestService.UnitTests
{
    public class GetOrderByIdHandlerTests
    {
        private readonly Mock<IOrderRepository> _repo = new();
        private readonly IMapper _mapper;
        public GetOrderByIdHandlerTests()
        {
            var loggerFactory = NullLoggerFactory.Instance;
            //var loggerFactory = LoggerFactory.Create(_ => { }); // lightweight
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<Application.Mapping.MappingProfile>();
            },
            loggerFactory);
            _mapper = config.CreateMapper();
        }

        [Fact]
        public async Task Handle_ShouldReturnNotFound_WhenMissing()
        {
            _repo.Setup(r => r.GetByIdAsync(It.IsAny<Guid>())).ReturnsAsync((Order?)null);

            var handler = new GetOrderByIdHandler(_repo.Object, _mapper);
            var result = await handler.Handle(new GetOrderByIdQuery(Guid.NewGuid()), CancellationToken.None);

            result.Type.Should().Be(Application.Common.Result.ResultType.NotFound);
        }

        [Fact]
        public async Task Handle_ShouldReturnOrderDto_WhenFound()
        {
            var order = new Order("Bob");
            order.AddItem(new OrderItem("Pen", 2, 1.5m));

            _repo.Setup(r => r.GetByIdAsync(It.IsAny<Guid>())).ReturnsAsync(order);

            var handler = new GetOrderByIdHandler(_repo.Object, _mapper);
            var result = await handler.Handle(new GetOrderByIdQuery(Guid.NewGuid()), CancellationToken.None);

            result.Type.Should().Be(Application.Common.Result.ResultType.Success);
            result.Value.Should().NotBeNull();
            result.Value.Customer.Should().Be("Bob");
        }
    }
}
